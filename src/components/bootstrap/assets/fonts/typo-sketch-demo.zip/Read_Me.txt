Thanks for downloading our font.

This is limited character demo version.
if you would like to consider using it for commercial projects. 
please visit 

http://www.studiotypo.com/

Thanks